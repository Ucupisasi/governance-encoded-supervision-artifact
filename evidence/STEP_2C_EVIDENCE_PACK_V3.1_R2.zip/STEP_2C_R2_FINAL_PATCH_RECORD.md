# Step 2C R2 Final Patch Record

## Scope

The Solidity contract and Hardhat configuration were not changed.

The final TypeScript test patch makes four bounded changes:

1. adds T18;
2. adds T19;
3. narrows the GTL-S7 title to match its actual assertions;
4. removes the unsupported word `routed` from the B5 title and narrows the boundary-section comment.

## T18 — Overpaid ordinary-review rejection

- Creates an Overpaid period position.
- Records status and review flag before the negative call.
- Calls `recordSupervisoryReviewOutcome(ClearedForClosure)`.
- Expects exact revert: `BLOCKED_OVERPAID_USES_EXTERNAL_RESOLUTION`.
- Confirms the reverted call leaves period status and `underReview` unchanged.
- Covers the claim-relevant branch previously reported at Solidity line 302.

## T19 — Review-outcome-triggered exception handoff

- Creates a valid Payable period with settlement evidence and a Complete decision.
- Records `ExceptionRequired` as the supervisory-review outcome.
- Confirms status becomes `SupervisoryReviewOutcomeRecorded` and `underReview` becomes true.
- Confirms closure reverts with `BLOCKED_PERIOD_UNDER_REVIEW`.
- Records an external-resolution reference.
- Confirms `underReview` becomes false and the main period status is not auto-advanced.
- Confirms closure then succeeds.
- Covers the claim-relevant branch previously reported at Solidity line 309.

## Evidence-label corrections

### GTL-S7

Current assertions record an evidence request event and an evidence submission event. They do not test a blocked action. The title is therefore changed from:

`GTL-S7 recorded/blocked: scoped evidence request then submission`

to:

`GTL-S7 recorded: scoped evidence request and submission`

### B5

Current assertions prove that a late invoice is blocked from being appended to a non-Open period. They do not execute exception routing. The title is therefore changed from:

`... late invoice routed, not appended`

to:

`... late invoice not appended`

## Deliberately not added

No test was added solely for `getSettlementCount()` at the previously uncovered line 393. It is a non-state-changing view getter and does not carry an intended evaluation claim.

## Expected execution status

Planned suite size: **19 tests**.  
Observed status before user execution: **NOT YET EXECUTED**.
