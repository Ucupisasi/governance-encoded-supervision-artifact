# Expected-Result Manifest — VATGovernancePoC V3.1-R2

**Artifact:** `VATGovernancePoC.sol` bounded-core V3.1  
**Test file:** `governance.spec.v3.1-r2.ts`  
**Planned suite size:** 19 Node.js test cases  
**Status before user execution:** NOT YET EXECUTED  
**Environment:** Hardhat 3 local simulated EVM development environment; application-level roles only; no network-level permissioning claim.

Expected results are committed before execution. A mismatch must be classified before code, test, or expectation is changed.

| ID | Evaluation episode | Expected controlled response | Claim boundary |
|---|---|---|---|
| GTL-S1 | Baseline conformance | Valid invoice progression reaches `Acknowledged` | Does not establish legal or institutional completeness |
| GTL-S2 | Baseline conformance | Posting succeeds after `Received` without buyer acknowledgment | Demonstrates encoded prerequisite only; not a general legal conclusion |
| GTL-S3 | Governance enforcement | Non-poster call reverts with `REJECTED_ROLE_REQUIRED` | Application-level role enforcement only |
| GTL-S4 | Baseline conformance | Payable branch reaches `Closed` after modeled evidence, complete decision, and cleared review | Does not reproduce or validate actual VAT settlement administration |
| GTL-S5 | Baseline conformance | Nil/no-activity path reaches `Closed` | Represents one bounded nil pathway, not every valid nil return |
| GTL-S6 | Governance enforcement | Settlement evidence on modeled Nil position reverts with `BLOCKED_PAYABLE_POSITION_REQUIRED` | Does not establish a universal institutional rule for all nil periods |
| GTL-S7 | Evidentiary interaction | Scoped request and submission events are recorded | No blocking claim unless a negative assertion is separately added |
| GTL-S8 | Governance enforcement | Unauthorized settlement-evidence call reverts with `REJECTED_ROLE_REQUIRED` | Role mapping is not participant-appraised or legally validated |
| B1 | Boundary challenge | Second invoice-to-period assignment reverts with `BLOCKED_INVOICE_ALREADY_POSTED` | Does not implement correction or relinking |
| B2 | Boundary challenge | Review before a Complete settlement decision reverts with `BLOCKED_COMPLETE_SETTLEMENT_REQUIRED` | Tests encoded ordering, not statutory sequence |
| B3 | Boundary challenge + positive path | Overpaid closure is blocked before external reference and succeeds after reference | Does not execute refund or compensation |
| B4 | Boundary challenge | Closure while under review reverts with `BLOCKED_PERIOD_UNDER_REVIEW` | Does not validate actual institutional exception procedure |
| B5 | Boundary challenge | Posting to a non-Open period reverts with `BLOCKED_PERIOD_NOT_OPEN` | Demonstrates blocking only; does not prove a late invoice was routed or amended |
| B6a | Boundary challenge | Zero source-time commitment reverts with `BLOCKED_SOURCE_TIME_COMMITMENT_REQUIRED` | Does not verify semantic truth or chronology of source time |
| T15 | Positive handoff semantics | Review flag blocks progression; external reference clears flag without auto-advance; original prerequisites still govern | Demonstrates encoded handoff semantics only |
| T16 | Positive overpaid semantics | Overpaid branch closes after external-resolution reference | No refund/compensation execution claim |
| T17 | Positive settlement semantics | Incomplete blocks; later Complete permits review/closure; both decisions traceable in event log | Event traceability, not institutional sufficiency |
| T18 | Coverage-targeted boundary challenge | Ordinary supervisory review on Overpaid reverts with `BLOCKED_OVERPAID_USES_EXTERNAL_RESOLUTION`; status and flag unchanged | Confirms branch exclusion; does not solve overpayment administration |
| T19 | Coverage-targeted handoff semantics | `ExceptionRequired` sets `underReview`; closure blocked; external reference clears flag without status bypass; closure then succeeds | Demonstrates encoded review-triggered handoff only |

## Mismatch classification

If an observed result differs from this manifest, classify it as one of:

1. test defect;
2. implementation defect;
3. specification mismatch;
4. environment/configuration mismatch;
5. residual represented boundary;
6. declared but unrepresented boundary.

Do not revise the expected result merely to make the suite pass.
